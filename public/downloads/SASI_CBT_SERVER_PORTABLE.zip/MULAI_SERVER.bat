@echo off
title SASI CBT Indonesia - Server Proktor Portable
color 0b
cd /d "%~dp0"

echo =======================================================================
echo          SISTEM ASESMEN SEKOLAH INDONESIA (SASI CBT)
echo             SERVER PROKTOR PORTABLE - MODA SEMI-ONLINE
echo =======================================================================
echo.
echo Sedang menyiapkan server lokal ruang ujian...
echo.

if not exist "SasiCbtServer.exe" (
    echo [ERROR] File SasiCbtServer.exe tidak ditemukan di folder ini!
    echo Silakan pastikan seluruh isi folder SASI_CBT_SERVER_PORTABLE diekstrak lengkap.
    echo.
    pause
    exit /b
)

if not exist "dist\index.html" (
    echo [ERROR] Folder dist\index.html tidak ditemukan!
    echo.
    pause
    exit /b
)

:: Jalankan server lokal
SasiCbtServer.exe

echo.
echo Server telah dimatikan.
pause
